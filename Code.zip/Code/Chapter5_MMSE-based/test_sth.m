N =16; M =64; K =8;

sigma_noise = 1; %noise variance
noise = zeros(N,N,K);
for k=1:K
    noise(:,:,k) = sigma_noise*eye(N);
end