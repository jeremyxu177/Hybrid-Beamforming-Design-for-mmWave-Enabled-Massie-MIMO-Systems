clear all;
Nt = 64; %BS antennas,Nt
Nr = 16; %MS antennas,Nr
L_cl = 2; %cluster number
L_ray = 5; %ray number

R_RF = 1; %RX RF
K = 1:1:15; % 8 MSs, users
T_RF = K; % TX RF
angle_spread = 5;

azimuth_range = [0, 2*pi];%azimuth angle
elevation_range = [-pi/2, pi/2];%elevation angle
SNR = -20; %SNR
sigma_noise = 1; %noise variance

num_Trials = 1000;

rate_MMSE_fully_digital = zeros(length(K),1); %fully digital MMSE
rate_MMSE_two_stage_sparse = zeros(length(K),1); %sparse MMSE
rate_MMSE_proposed = zeros(length(K),1); %proposed MMSE

tic
for K_index=1:length(K)
    
    noise = zeros(Nr,Nr,K_index);
    for k=1:K(K_index)
        noise(:,:,k) = sigma_noise*eye(Nr);  %identity matrix,noise
        
        
        P = sigma_noise*10^(SNR/10)*K(K_index); %sum power
        for trial=1:num_Trials
            %         [H,D,A_r,A_t] = channel_generator_MU(M,N,L,K,ARRAY,azimuth_range,elevation_range);
            [H,D,A_r,A_t] = channel_generator_MU_V2(Nt,Nr,L_cl,L_ray,K(K_index),azimuth_range,elevation_range,angle_spread);
            %channel, gain, steering vector
            H_hat = zeros(R_RF,Nt,K(K_index));
            noise_hat = zeros(R_RF,R_RF,K(K_index));
            %         W = zeros(N,RF_R,K);
            W_RF = zeros(Nr,R_RF,K(K_index));
            A_t_combine = [];
            for k=1:K(K_index)
                A_t_combine = [A_t_combine,A_t(:,:,k)];
                temp = zeros(L_cl*L_ray,1);
                for i=1:L_cl*L_ray
                    temp(i) = norm(A_r(:,i,k)'*H(:,:,k));
                end
                for r=1:R_RF
                    [maxx, index] = max(temp);
                    W_RF(:,r,k) = A_r(:,index,k);
                    temp(index) = 0;
                end
                H_hat(:,:,k) = W_RF(:,:,k)'*H(:,:,k);
                noise_hat(:,:,k) = W_RF(:,:,k)'*noise(:,:,k)*W_RF(:,:,k);
                %             noise_hat(:,:,k) = W_RF(:,:,k)'*noise(:,:,k);
            end
            
            % MMSE precoder - Fully Digital
            [rate, F_MMSE, W_MMSE] = MMSE_fully_digital(H_hat, P, noise_hat);
            rate_MMSE_fully_digital(K_index) = rate_MMSE_fully_digital(K_index) + sum(sum(rate));
            
            F_MMSE_vec = [];
            for k=1:K(K_index)
                F_MMSE_vec = [F_MMSE_vec, F_MMSE(:,:,k)];
            end
            %
            %         % OMP to approximate the precoder
            [F_RF, F_BB] = OMP_sparse(F_MMSE_vec, eye(Nt), A_t_combine, T_RF, P);
            for k=1:K(K_index)
                V(:,:,k) = F_RF*F_BB(:,R_RF*(k-1)+1:R_RF*k);
            end
            rate = rate_MIMO_MU(H_hat,V,W_MMSE,noise_hat);
            rate_MMSE_two_stage_sparse(K_index) = rate_MMSE_two_stage_sparse(K_index) + sum(sum(rate));
            %
            %         % Hybrid MMSE precoder - proposed
            [rate, F_RF, F_BB, V, U] = MMSE_hybrid(H_hat, A_t_combine, T_RF, P, noise_hat);
            rate_MMSE_proposed(K_index) = rate_MMSE_proposed(K_index) + sum(sum(rate));
        end
    end
end
% rate_MMSE_fully_digital = rate_MMSE_fully_digital/num_Trials
% rate_BD = rate_BD/noOfTrials
rate_MMSE_two_stage_sparse = rate_MMSE_two_stage_sparse/num_Trials
rate_MMSE_proposed = rate_MMSE_proposed/num_Trials

toc

figure;
% plot(K, rate_MMSE_fully_digital, 'r--o','LineWidth',2); hold on;
plot(K, rate_MMSE_two_stage_sparse, 'c--o','LineWidth',2); hold on;
plot(K, rate_MMSE_proposed ,'b--o','LineWidth',2); hold on;
grid on;
xlabel('Number of Users');
ylabel('Spectral Efficiency (bits/s/Hz)');
% legend('Fully Digital MMSE', 'Two-stage sparse MMSE', 'Proposed MMSE');
legend('Two-stage sparse MMSE', 'Proposed MMSE');
axis([2 15 0 70]);