function [X_RF, X_BB] = OMP_sparse(A, B, C, N_RF, P)
X_RF = [];
X_res = A;
for i=1:N_RF
    Omega = C'*B'*X_res;
    [~,index] = max(diag(Omega*Omega'));
    X_RF = [X_RF, C(:,index)];
    C(:,index) = [];
    X_BB = pinv(X_RF'*(B'*B)*X_RF)*X_RF'*B'*A;
    temp = A - B*X_RF*X_BB;
    X_res = temp/sqrt(trace(temp*temp'));
end
if P ~= 0
    X_BB = sqrt(P)*X_BB/sqrt(trace((X_RF*X_BB)*(X_RF*X_BB)'));
end
    