function [rate, V, U] = MMSE_fully_digital(H, sum_power, noise)

[N,M,K] = size(H);
H_s = [];
alpha = 0;
for i=1:K
    H_s = [H_s; H(:,:,i)];
    alpha = alpha + trace(noise(:,:,i));
end
alpha = alpha/sum_power;

T = (H_s'*H_s + alpha*eye(M))\H_s';
T = T*sqrt(sum_power/trace(T*T'));
% T = T*sqrt(sum_power/(norm(T,'fro')));

U = zeros(N,N,K);
V = zeros(M,N,K);

for i=1:K
    [u,S,v] = svd(H(:,:,i)*T(:,N*(i-1)+1:N*i));
    U(:,:,i) = u;
    V(:,:,i) = T(:,N*(i-1)+1:N*i)*v;
end
rate = rate_MIMO_MU(H,V,U,noise);