function [H,D,A_r,A_t] = channel_generator_MU_V2(Nt,Nr,L_clus,L_ray,K,azi_range,ele_range,angle_spread)
A_r = zeros(Nr,L_clus*L_ray,K);
A_t = zeros(Nt,L_clus*L_ray,K);
Nr_width = sqrt(Nr);
Nt_width = sqrt(Nt);
H = zeros(Nr,Nt,K);
D = zeros(L_clus*L_ray,L_clus*L_ray,K);
% normalization_factor = sqrt(Nt*Nr/L_clus*L_ray);
normalization_factor = sqrt((Nt*Nr)/(L_clus*L_ray));
    for k=1:K
        D(:,:,k) = normalization_factor*diag(sqrt(1/2)*(randn(L_clus*L_ray,1) + 1i*randn(L_clus*L_ray,1)));
        for clus = 1:L_clus
            mean_theta_r = (ele_range(2) - ele_range(1))*rand + ele_range(1);
            mean_phi_r = (azi_range(2) - azi_range(1))*rand + azi_range(1);
            mean_theta_t = (ele_range(2) - ele_range(1))*rand + ele_range(1);
            mean_phi_t = (azi_range(2) - azi_range(1))*rand + azi_range(1);
            for ray = 1:L_ray
                a_r = zeros(Nr_width,Nr_width);
                phi_angle = LaplaceDistribution(mean_phi_r, angle_spread);
                theta_angle = LaplaceDistribution(mean_theta_r, angle_spread);
%                 phi_angle = laprnd(1,L_ray,mean_phi_r, angle_spread);
%                 theta_angle = laprnd(1,L_ray,mean_theta_r, angle_spread);
                for m=1:Nr_width
                    for n=1:Nr_width
                        a_r(m,n) = 1/Nr_width*exp(1i*pi*((m-1)*sin(phi_angle)*sin(theta_angle) + (n-1)*cos(theta_angle)));
                    end
                end
    %         a_r = 1/W*exp(1i*pi*sin(theta_r)*(0:N-1));
                A_r(:,(clus-1)*L_ray+ray,k) = vec(a_r);
                
                a_t = zeros(Nt_width,Nt_width);
                phi_angle = LaplaceDistribution(mean_phi_t, angle_spread);
                theta_angle = LaplaceDistribution(mean_theta_t, angle_spread);
%                 phi_angle = laprnd(1,L_ray,mean_phi_t, angle_spread);
%                 theta_angle = laprnd(1,L_ray,mean_theta_t, angle_spread);
                for m=1:Nt_width
                    for n=1:Nt_width
                        a_t(m,n) = 1/Nt_width*exp(1i*pi*((m-1)*sin(phi_angle)*sin(theta_angle) + (n-1)*cos(theta_angle)));
                    end
                end        
                A_t(:,(clus-1)*L_ray+ray,k)  = vec(a_t);
            end
        end
        H(:,:,k) = A_r(:,:,k)*D(:,:,k)*A_t(:,:,k)';
    end

end

    