clear all;
Nt = 64; %BS antennas,Nt
Nr = 16; %MS antennas,Nr
L_cl = 2; %cluster number
L_ray = 5; %ray number
T_RF = 8; % TX RF
R_RF = 1; %RX RF
K = 8; % 8 MSs, users
angle_spread = 0:1:10;

azimuth_range = [0, 2*pi];%azimuth angle
elevation_range = [-pi/2, pi/2];%elevation angle
% SNR = -35:2.5:-15; %SNR
SNR = -15; %SNR
sigma_noise = 1; %noise variance
noise = zeros(Nr,Nr,K);
for k=1:K
    noise(:,:,k) = sigma_noise*eye(Nr);  %identity matrix,noise
end
num_Trials = 500;

rate_MMSE_fully_digital = zeros(length(angle_spread),1); %fully digital MMSE
rate_MMSE_two_stage_sparse = zeros(length(angle_spread),1); %sparse MMSE
rate_MMSE_proposed = zeros(length(angle_spread),1); %proposed MMSE

tic
for angle_index=1:length(angle_spread)
    P = sigma_noise*10^(SNR/10)*K; %sum power
    for trial=1:num_Trials
        [H,D,A_r,A_t] = channel_generator_MU_V2(Nt,Nr,L_cl,L_ray,K,azimuth_range,elevation_range,angle_spread(angle_index));
%         [H,D,A_r,A_t] = quantized_channel(Nt,Nr,L_cl,L_ray,K,azimuth_range,elevation_range,angle_spread);
        %channel, gain, steering vector
        H_hat = zeros(R_RF,Nt,K);
        noise_hat = zeros(R_RF,R_RF,K);
%         W = zeros(N,RF_R,K);
        W_RF = zeros(Nr,R_RF,K);
        A_t_combine = [];
        for k=1:K
            A_t_combine = [A_t_combine,A_t(:,:,k)];
            temp = zeros(L_cl*L_ray,1);
            for i=1:L_cl*L_ray
                temp(i) = norm(A_r(:,i,k)'*H(:,:,k));
            end
            for r=1:R_RF
                [maxx, index] = max(temp);
                W_RF(:,r,k) = A_r(:,index,k);
                temp(index) = 0;
            end
            H_hat(:,:,k) = W_RF(:,:,k)'*H(:,:,k);
            noise_hat(:,:,k) = W_RF(:,:,k)'*noise(:,:,k)*W_RF(:,:,k);
%             noise_hat(:,:,k) = W_RF(:,:,k)'*noise(:,:,k);
        end
        
         % MMSE precoder - Fully Digital
        [rate, F_MMSE, W_MMSE] = MMSE_fully_digital(H_hat, P, noise_hat);
        rate_MMSE_fully_digital(angle_index) = rate_MMSE_fully_digital(angle_index) + sum(sum(rate));
        F_MMSE_vec = [];
        for k=1:K
            F_MMSE_vec = [F_MMSE_vec, F_MMSE(:,:,k)];
        end
%         
%         % OMP to approximate the precoder
        [F_RF, F_BB] = OMP_sparse(F_MMSE_vec, eye(Nt), A_t_combine, T_RF, P);
        for k=1:K
            V(:,:,k) = F_RF*F_BB(:,R_RF*(k-1)+1:R_RF*k);
        end
        rate = rate_MIMO_MU(H_hat,V,W_MMSE,noise_hat);
        rate_MMSE_two_stage_sparse(angle_index) = rate_MMSE_two_stage_sparse(angle_index) + sum(sum(rate));
% 
%         % Hybrid MMSE precoder - proposed
        [rate, F_RF, F_BB, V, U] = MMSE_hybrid(H_hat, A_t_combine, T_RF, P, noise_hat);
        rate_MMSE_proposed(angle_index) = rate_MMSE_proposed(angle_index) + sum(sum(rate));

    end
end
rate_MMSE_fully_digital = rate_MMSE_fully_digital/num_Trials
rate_MMSE_two_stage_sparse = rate_MMSE_two_stage_sparse/num_Trials
rate_MMSE_proposed = rate_MMSE_proposed/num_Trials

toc

figure;
plot(angle_spread, rate_MMSE_fully_digital, 'r--o','LineWidth',2); hold on;
plot(angle_spread, rate_MMSE_two_stage_sparse, 'c--o','LineWidth',2); hold on;
plot(angle_spread, rate_MMSE_proposed ,'b--o','LineWidth',2); hold on;
grid on;
xlabel('Angle Spread');
ylabel('Spectral Efficiency (bits/s/Hz)');
legend('Fully Digital MMSE', 'Two stage sparse MMSE', 'Proposed MMSE');
axis([0 10 0 40]);