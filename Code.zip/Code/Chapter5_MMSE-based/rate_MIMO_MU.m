function rate = rate_MIMO_MU(H,V,U,noise)
%sum rate function
[N,M,K] = size(H);
if size(V,3) == 1
    rate = zeros(K,1);
    for i=1:K
        SIG = H(:,:,i)*V(:,i)*V(:,i)'*H(:,:,i)';
        INRS = noise(:,:,i) - SIG + H(:,:,i)*(V*V')*H(:,:,i)';
        if norm(U(:,i)) < 1e-10
            rate(i) = 0;
        else
            rate(i) = real(log2(1 + (U(:,i)'*SIG*U(:,i))/(U(:,i)'*INRS*U(:,i))));
        end
    end
else
    S = size(V,2);
    rate = zeros(S,K);
    for i=1:K
        INRS = noise(:,:,i);
% %         for s=1:S
%             INRS = noise(:,:,i) + H(:,:,i)*V(:,:,i)*V(:,:,i)'*H(:,:,i)';
%         end
        for j=1:K
            INRS = INRS + H(:,:,i)*V(:,:,j)*V(:,:,j)'*H(:,:,i)';
        end
        for s=1:S
            SIG = H(:,:,i)*V(:,s,i)*V(:,s,i)'*H(:,:,i)';
            if norm(U(:,s,i)) < 1e-10
                rate(s,i) = 0;
            else
                rate(s,i) = real(log2(U(:,s,i)'*INRS*U(:,s,i) / (U(:,s,i)'*(INRS-SIG)*U(:,s,i))));
            end
        end
    end
end