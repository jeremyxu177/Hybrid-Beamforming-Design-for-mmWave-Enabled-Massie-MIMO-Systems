function [X_RF, X_BB] = Hybrid_Transceiver_2(C, A, B, N_RF, P)
X_RF = [];
X_res = B;

for i = 1:N_RF
    Phi = A'*C'*X_res;
    [~,ind] = max(diag(Phi*Phi'));
    X_RF = [X_RF A(:,ind)];
    A(:,ind)= [];
    X_BB = pinv(X_RF'*C'*C*X_RF)*X_RF'*C'*B;
    temp = B - C*X_RF*X_BB;
%     X_res = temp/norm(B - C*X_RF * X_BB,'fro');
    X_res = temp/sqrt(trace(temp*temp'));
end
if P~=0
%     X_BB = (sqrt(P)*X_BB)/norm(X_RF * X_BB,'fro');
    X_BB = sqrt(P)*X_BB/sqrt(trace((X_RF*X_BB)*(X_RF*X_BB)'));
end


% 
% function [X_RF, X_BB] = Hybrid_Transceiver(A, B, X_c, N_RF, P)
% X_RF = [];
% X_res = A;
% for i=1:N_RF
%     Omega = X_c'*B'*X_res;
%     [~,index] = max(diag(Omega*Omega'));
%     X_RF = [X_RF, X_c(:,index)];
%     X_c(:,index) = [];
%     X_BB = pinv(X_RF'*(B'*B)*X_RF)*X_RF'*B'*A;
%     temp = A - B*X_RF*X_BB;
%     X_res = temp/sqrt(trace(temp*temp'));
% end
% if P ~= 0
%     X_BB = sqrt(P)*X_BB/sqrt(trace((X_RF*X_BB)*(X_RF*X_BB)'));
% end
%     