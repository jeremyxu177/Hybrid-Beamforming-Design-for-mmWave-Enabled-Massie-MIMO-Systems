function [rate, F_RF, F_BB, V, U] = MMSE_hybrid(H, A_t, Ns, sum_power, noise)

[N,M,K] = size(H);
H_s = [];
alpha = 0;
for i=1:K
    H_s = [H_s; H(:,:,i)];
    alpha = alpha + trace(noise(:,:,i));
end
alpha = alpha/sum_power;

F_res = eye(K*N);
F_RF = [];

for i=1:Ns
    Phi = A_t'*H_s'*F_res;
    [~,index] = max(diag(Phi*Phi'));
    F_RF = [F_RF, A_t(:,index)];
    F_BB = pinv(F_RF'*(H_s'*H_s)*F_RF + alpha*(F_RF'*F_RF))*F_RF'*H_s';%pinv(F_RF'*F_RF)*F_RF'*F_opt;
    temp = (eye(K*N) - H_s*F_RF*F_BB);
    F_res = temp/sqrt(trace(temp*temp'));
end
F_BB = sqrt(sum_power)*F_BB/sqrt(trace((F_RF*F_BB)*(F_RF*F_BB)'));

U = zeros(N,N,K);
V = zeros(M,N,K);

for i=1:K
    [u,S,v] = svd(H(:,:,i)*F_RF*F_BB(:,N*(i-1)+1:N*i));
    U(:,:,i) = u;
    V(:,:,i) = F_RF*F_BB(:,N*(i-1)+1:N*i)*v;
end
rate = rate_MIMO_MU(H,V,U,noise);

