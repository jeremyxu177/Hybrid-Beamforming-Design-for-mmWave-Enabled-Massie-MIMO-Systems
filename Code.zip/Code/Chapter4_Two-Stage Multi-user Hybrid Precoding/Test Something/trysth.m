% Num_users=4; % Number of users
% 
% for TX_ant= 1:1:10; %Number of UPA TX antennas
%     TX_ant_w(TX_ant)= round(sqrt(TX_ant)); % width
%     TX_ant_h(TX_ant)= round(sqrt(TX_ant)); % hieght 
%     ind_TX_w(TX_ant)= reshape(repmat([0:1:TX_ant_w-1],TX_ant_h,1),1,TX_ant_w*TX_ant_h);
% end


TX_ant= [4,9,16]; %Number of UPA TX antennas
b=[];
for i = 1:length(TX_ant)
%     TX_ant_w(i) = round(sqrt(TX_ant(i))); % width
%     TX_ant_h(i) = round(sqrt(TX_ant(i))); % hieght 
      TX_ant(i);
      ind_x(i) = convert_to_index(TX_ant(i));
      b=b+ind_(i);
%     tem = [0:1:TX_ant_w(i)-1];
%     a = [a;tem];
%     a(i) = repmat(tem,[TX_ant_h(i),1]);
%     a(i) = repmat([1:TX_ant_w(i)],[TX_ant_h(i),1]);
    
end
% a = repmat([0:TX_ant_w-1],[TX_ant_h,1]);

% ind_TX_w= repmat([0:1:TX_ant_w-1],TX_ant_h,1),1,TX_ant_w*TX_ant_h);
% ind_TX_w=reshape(repmat([0:1:TX_ant_w-1],TX_ant_h,1),1,TX_ant_w*TX_ant_h);
% ind_TX_h=repmat([0:1:TX_ant_h-1],1,TX_ant_w);
% N_t=[8 16 32 64 128 160 200 256];
% N_user=4;
% N_r = 2;
% l=0;
% for NBS=N_t
%         l=l+1;
%     H=1/sqrt(2)*(randn(N_user*N_r,NBS)+j*randn(N_user*N_r,NBS));
% end