function ind_RX = RX_array_index(RX_ant)
% a = sqrt(TX_ant);
% b = sqrt(TX_ant);
% %     ind_x = repmat([0:1:a-1],[a,1]);
% ind_x = reshape(repmat([0:1:a-1],[a,1]),1,a*b);

RX_ant_w=round(sqrt(RX_ant)); % width
RX_ant_h=round(sqrt(RX_ant)); % hieght 
ind_RX_w=reshape(repmat([0:1:RX_ant_w-1],RX_ant_h,1),1,RX_ant_w*RX_ant_h);
ind_RX_h=repmat([0:1:RX_ant_h-1],1,RX_ant_w);
ind_RX = [ind_RX_w;ind_RX_h];

end