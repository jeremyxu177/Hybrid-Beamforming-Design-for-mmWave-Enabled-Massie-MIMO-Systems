function [H,a_TX,a_RX]=generate_channels(Num_users,TX_ant_w,TX_ant_h,RX_ant_w,RX_ant_h,Num_paths,B_TX,B_RX)

H=zeros(Num_users,RX_ant_w*RX_ant_h,TX_ant_w*TX_ant_h);  % One user channel
a_TX=zeros(TX_ant_w*TX_ant_h,Num_users); % TX steering vector
a_RX=zeros(RX_ant_w*RX_ant_h,Num_users); % RX steering vector
ind_TX_w=reshape(repmat([0:1:TX_ant_w-1],TX_ant_h,1),1,TX_ant_w*TX_ant_h);
ind_TX_h=repmat([0:1:TX_ant_h-1],1,TX_ant_w);
ind_RX_w=reshape(repmat([0:1:RX_ant_w-1],RX_ant_h,1),1,RX_ant_w*RX_ant_h);
ind_RX_h=repmat([0:1:RX_ant_h-1],1,RX_ant_w);

Num_Directions_TX=2^B_TX;
Step_TX=2*pi/Num_Directions_TX;
aoa_el_codebook = pi*0.5:Step_TX:pi-0.00001;
aoa_az_codebook = 0:Step_TX:2*pi-0.00001;

Num_Directions_RX = 2^B_RX;
Step_RX=2*pi/Num_Directions_RX;
aod_el_codebook = pi*0.5:Step_RX:pi-0.00001;
aod_az_codebook = 0:Step_RX:2*pi-0.00001;

% Constructing the channels
for u=1:1:Num_users
    AoD_el(u,:)=pi*rand(1,Num_paths)-pi/2;
    aod_el_quantized(u,:) = map_to_nearest(AoD_el(u,:),aod_el_codebook);
    AoD_az(u,:)=2*pi*rand(1,Num_paths);
    aod_az_quantized(u,:) = map_to_nearest(AoD_az(u,:),aod_az_codebook);
    AoA_el(u,:)=pi*rand(1,Num_paths)-pi/2;
    aoa_el_quantized(u,:) = map_to_nearest(AoA_el(u,:),aoa_el_codebook);
    AoA_az(u,:)=2*pi*rand(1,Num_paths);
    aoa_az_quantized(u,:) = map_to_nearest(AoA_az(u,:),aoa_az_codebook);
    
    alpha(u,:)=sqrt(1/Num_paths)*sqrt(1/2)*(randn(1,Num_paths)+1j*randn(1,Num_paths));

    Temp_Channel=zeros(RX_ant_w*RX_ant_h,TX_ant_w*TX_ant_h);
    for l=1:1:Num_paths
        a_TX(:,u)=transpose(sqrt(1/(TX_ant_w*TX_ant_h))*exp(1j*pi*(ind_TX_w*sin(aod_az_quantized(u,l))*sin(aod_el_quantized(u,l))+ind_TX_h*cos(aod_el_quantized(u,l))) ));
        a_RX(:,u)=transpose(sqrt(1/(RX_ant_w*RX_ant_h))*exp(1j*pi*(ind_RX_w*sin(aoa_az_quantized(u,l))*sin(aoa_el_quantized(u,l))+ind_RX_h*cos(aoa_el_quantized(u,l))) ));
        Temp_Channel=Temp_Channel+sqrt((TX_ant_w*TX_ant_h)*(RX_ant_w*RX_ant_h))*alpha(u,l)*a_RX(:,u)*a_TX(:,u)';
    end
    H(u,:,:)=Temp_Channel;
end

end