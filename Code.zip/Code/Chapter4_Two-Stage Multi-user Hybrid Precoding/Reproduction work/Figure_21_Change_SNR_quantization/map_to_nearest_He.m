function quantized_He = map_to_nearest_He(original,H_codebook)
load('data.mat');
H_codebook = H_list;
H_codebook = transpose(reshape(transpose(H_codebook(:,:)),4,256));
H_codebook = H_codebook(1:64,:);
quantized_He = [];
% 'code book', size(H_list)
% 'code book', original;
minn = 100000000;
index = 1;
for i = 1:64
    
    diff = sum(abs(original - H_codebook(i,:).^2));
    if diff<minn
        index = i;
        minn = diff;
    end
%     diff
%     'index'
%     index
    
    %     quantized_angle = [quantized_angle quantized_angle(i)];
end
quantized_He = H_codebook(index,:)
