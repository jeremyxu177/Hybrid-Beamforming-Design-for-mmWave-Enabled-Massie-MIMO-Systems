function ind_TX = TX_array_index(N)
% a = sqrt(TX_ant);
% b = sqrt(TX_ant);
% %     ind_x = repmat([0:1:a-1],[a,1]);
% ind_x = reshape(repmat([0:1:a-1],[a,1]),1,a*b);

TX_ant_w=round(sqrt(N)); % width
TX_ant_h=round(sqrt(N)); % hieght 
ind_TX_w=reshape(repmat([0:1:TX_ant_w-1],TX_ant_h,1),1,TX_ant_w*TX_ant_h);
ind_TX_h=repmat([0:1:TX_ant_h-1],1,TX_ant_w);
ind_TX = [ind_TX_w;ind_TX_h];

end