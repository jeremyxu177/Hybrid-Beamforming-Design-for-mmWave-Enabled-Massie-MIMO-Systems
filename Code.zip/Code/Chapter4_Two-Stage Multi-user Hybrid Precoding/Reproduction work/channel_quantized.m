function [H,a_TX,a_RX]= channel_quantized(Num_users,TX_ant,RX_ant,Num_paths,B_TX,B_RX)
TX_ant_w=round(sqrt(TX_ant)); % width
TX_ant_h=round(sqrt(TX_ant)); % hieght 
RX_ant_w=round(sqrt(RX_ant)); % width
RX_ant_h=round(sqrt(RX_ant)); % hieght 

H=zeros(Num_users,RX_ant_w*RX_ant_h,TX_ant_w*TX_ant_h);  % One user channel
a_TX=zeros(TX_ant_w*TX_ant_h,Num_users); % TX steering vector
a_RX=zeros(RX_ant_w*RX_ant_h,Num_users); % RX steering vector

ind_TX = TX_array_index(TX_ant);
ind_RX = RX_array_index(RX_ant);

Num_Directions_TX=2^B_TX;
Step_TX=2*pi/Num_Directions_TX;
aoa_el_codebook = pi*0.5:Step_TX:pi-0.00001;
aoa_az_codebook = 0:Step_TX:2*pi-0.00001;

Num_Directions_RX = 2^B_RX;
Step_RX=2*pi/Num_Directions_RX;
aod_el_codebook = pi*0.5:Step_RX:pi-0.00001;
aod_az_codebook = 0:Step_RX:2*pi-0.00001;

% Constructing the channels
for u=1:1:Num_users
    AOD_el(u,:)=pi*rand(1,Num_paths)-pi/2;
    aod_el_quantized(u,:) = map_to_nearest(AOD_el(u,:),aod_el_codebook);
    
    AoD_az(u,:)=2*pi*rand(1,Num_paths);
    aod_az_quantized(u,:) = map_to_nearest(AoD_az(u,:),aod_az_codebook);
    
    AoA_el(u,:)=pi*rand(1,Num_paths)-pi/2;
    aoa_el_quantized(u,:) = map_to_nearest(AoA_el(u,:),aoa_el_codebook);
    
    AoA_az(u,:)=2*pi*rand(1,Num_paths);
    aoa_az_quantized(u,:) = map_to_nearest(AoA_az(u,:),aoa_az_codebook);
    
    alpha(u,:)=sqrt(1/Num_paths)*sqrt(1/2)*(randn(1,Num_paths)+1j*randn(1,Num_paths));

    Temp_Channel=zeros(RX_ant_w*RX_ant_h,TX_ant_w*TX_ant_h);
    for l=1:1:Num_paths
        a_TX(:,u)=transpose(sqrt(1/(TX_ant_w*TX_ant_h))*exp(1j*pi*(ind_TX(1,:)*sin(aod_az_quantized(u,l))*sin(aod_el_quantized(u,l))+ind_TX(2,:)*cos(aod_el_quantized(u,l))) ));
        a_RX(:,u)=transpose(sqrt(1/(RX_ant_w*RX_ant_h))*exp(1j*pi*(ind_RX(1,:)*sin(aoa_az_quantized(u,l))*sin(aoa_el_quantized(u,l))+ind_RX(2,:)*cos(aoa_el_quantized(u,l))) ));
        Temp_Channel=Temp_Channel+sqrt((TX_ant_w*TX_ant_h)*(RX_ant_w*RX_ant_h))*alpha(u,l)*a_RX(:,u)*a_TX(:,u)';
    end
    H(u,:,:)=Temp_Channel;
end

end