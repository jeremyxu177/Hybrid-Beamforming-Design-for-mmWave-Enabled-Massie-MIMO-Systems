function C_phi_RX = Codebook_RX_phi(Num_Qbits)
% C = [];

Num_Directions=2^Num_Qbits;
Step=2*pi/Num_Directions;
% Theta_Quantized=0:Step:2*pi-.00001;
% C_phi_TX = zeros(length(Step));
% C_theta_TX = zeros(length(Step));
% C_phi_RX = zeros(length(Step));
% C_theta_RX = zeros(length(Step));
% 
% C_phi_TX = 0:Step:pi/3-0.00001;
% C_theta_TX = 0:Step:pi/9-0.00001;
C_phi_RX = 0:Step:2*pi-0.00001;
% C_theta_RX = 0:Step:2*pi-0.00001;


end