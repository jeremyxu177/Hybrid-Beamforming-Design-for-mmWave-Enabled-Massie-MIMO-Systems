function C_theta_TX = Codebook_TX_theta(Num_Qbits)
% C = [];

Num_Directions=2^Num_Qbits;
Step=2*pi/Num_Directions;
% Theta_Quantized=0:Step:2*pi-.00001;
C_theta_TX = zeros(length(Step));

C_theta_TX = 0:Step:pi/9-0.00001;


end