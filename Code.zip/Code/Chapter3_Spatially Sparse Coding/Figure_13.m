
%% System setting
Nt = 64; % number of transmit antennas
Nr = 16; % number of receive antennas

NRFt = 4; % NRFt = number of RF chain in transmiter
NRFr = 4; % NRFr = number of RF chain in receiver

Ns = 1; % 1 or 2 streams

N_cl = 8;  % scattering cluster
N_ray = 10; % propagation paths in a cluster

As = 7.5 * pi / 180;  % angular spread of 7.5 degrees

j = sqrt(-1);
kd = pi; % k*d = 2*pi/lambda*d = 2*pi/lambda * (0.5*lambda) = pi

% Tx angle range
phi_TX_min = 0;    phi_TX_max = 60*pi/180;    % azimuth : [0:60]
theta_TX_min = 0;  theta_TX_max = 20*pi/180;  % elevation : [0:20]

% Rx angle range
phi_RX_min = 0;    phi_RX_max = 360*pi/180;    % azimuth : [0~360]
theta_RX_min = 0;  theta_RX_max = 360*pi/180;  % elevation : [0~360]

% SNR range
SNR_dB = 0; % SNR range in dB
SNR_Linear = 10.^(SNR_dB/10); % SNR range in linear power

N = 500; % number of random channel realizations

gamma = sqrt((Nt*Nr)/(N_cl*N_ray)); % normalization factor
sigma_square = 1;
%set UPA index
[Y_t,Z_t] = meshgrid(0:sqrt(Nt)-1,0:sqrt(Nt)-1);% index m of antenna element in Y axis, index n in Z axis 
[Y_r,Z_r] = meshgrid(0:sqrt(Nr)-1,0:sqrt(Nr)-1);% index m of antenna element in Y axis, index n in Z axis 

% Spectral Efficiency
SE_optimal = zeros(length(SNR_dB),N);
SE_hybrid = zeros(length(SNR_dB),N);
SE_beamsteer = zeros(length(SNR_dB),N);

Num_Qbits = 2:1:9;
%% Simulation

for Bits_index = 1:length(Num_Qbits)
    SNR = SNR_Linear;
    
    for n = 1:N
        %% channel realization
        phi_t_mean = phi_TX_min + (phi_TX_max - phi_TX_min)*rand(N_cl,1); % uniform random in [min, max]
%         phi_t_codebook = Codebook_TX_phi(Num_Qbits);
%         phi_t_quantized = map_to_nearest(phi_t_mean,phi_t_codebook);
%         phi_t_quantized = reshape(phi_t_quantized,8,1);
        
        theta_t_mean = theta_TX_min + (theta_TX_max - theta_TX_min)*rand(N_cl,1);
%         theta_t_codebook = Codebook_TX_theta(Num_Qbits);
%         theta_t_quantized = map_to_nearest(theta_t_mean,theta_t_codebook);
%         theta_t_quantized = reshape(theta_t_quantized,8,1);
        
        phi_r_mean = phi_RX_min + (phi_RX_max - phi_RX_min)*rand(N_cl,1);
%         phi_r_codebook = Codebook_RX_phi(Num_Qbits);
%         phi_r_quantized = map_to_nearest(phi_r_mean,phi_r_codebook);
%         phi_r_quantized = reshape(phi_r_quantized,8,1);
        
        theta_r_mean = theta_RX_min + (theta_RX_max - theta_RX_min)*rand(N_cl,1);
%         theta_r_codebook = Codebook_RX_theta(Num_Qbits);
%         theta_r_quantized = map_to_nearest(theta_r_mean,theta_r_codebook);
%         theta_r_quantized = reshape(theta_r_quantized,8,1);
        
        alpha = zeros(N_cl,N_ray);
        phi_t = zeros(N_cl,N_ray);
        theta_t = zeros(N_cl,N_ray); %8*10
        phi_r = zeros(N_cl,N_ray);
        theta_r = zeros(N_cl,N_ray);
        

        At = []; %steering vector
        Ar = [];
        H = zeros(Nr,Nt);   % Nr x Nt matrix H
        
        
        for i = 1:N_cl % for each cluster i
            phi_t(i,:) = laprnd(1,N_ray,phi_t_mean(i),As); % tx; iid laplacian distribution
            phi_t_codebook = Codebook_TX_phi(Num_Qbits(Bits_index));
            phi_t_quantized(i,:) = map_to_nearest(phi_t(i,:),phi_t_codebook);
%             phi_t_quantized = reshape(phi_t_quantized,8,1);
            
            theta_t(i,:) = laprnd(1,N_ray,theta_t_mean(i),As);
            theta_t_codebook = Codebook_TX_theta(Num_Qbits(Bits_index));
            theta_t_quantized(i,:) = map_to_nearest(theta_t(i,:),theta_t_codebook);
%             theta_t_quantized = reshape(theta_t_quantized,8,1);

            phi_r(i,:) = laprnd(1,N_ray,phi_r_mean(i),As); % rx
            phi_r_codebook = Codebook_RX_phi(Num_Qbits(Bits_index));
            phi_r_quantized(i,:) = map_to_nearest(phi_r(i,:),phi_r_codebook);
%         phi_r_quantized = reshape(phi_r_quantized,8,1);

            theta_r(i,:) = laprnd(1,N_ray,theta_r_mean(i),As);
            theta_r_codebook = Codebook_RX_theta(Num_Qbits(Bits_index));
            theta_r_quantized(i,:) = map_to_nearest(theta_r(i,:),theta_r_codebook);
%         theta_r_quantized = reshape(theta_r_quantized,8,1);
            
            
%             phi_t_quantized(i,:) = laprnd(1,N_ray,phi_t_quantized(i),As); % tx; iid laplacian distribution
%             theta_t_quantized(i,:) = laprnd(1,N_ray,theta_t_quantized(i),As);
%             phi_r_quantized(i,:) = laprnd(1,N_ray,phi_r_quantized(i),As); % rx
%             theta_r_quantized(i,:) = laprnd(1,N_ray,theta_r_quantized(i),As);
%             phi_t(i,:) = LaplaceDistribution(phi_t_mean(i),As); % tx; iid laplacian distribution
%             theta_t(i,:) = LaplaceDistribution(theta_t_mean(i),As);
%             phi_r(i,:) = LaplaceDistribution(phi_r_mean(i),As); % rx
%             theta_r(i,:) = LaplaceDistribution(theta_r_mean(i),As);
            alpha(i,:) = (randn(1,N_ray) + j*randn(1,N_ray))/sqrt(2); % gain

            for r = 1:N_ray % for each ray r
                % array response vector for UPA
%                 at = 1/sqrt(Nt)*exp(j*kd*(Y_t(:)*sin(phi_t(i,r))*sin(theta_t(i,r))+Z_t(:)*cos(theta_t(i,r))));%tx 
%                 ar = 1/sqrt(Nr)*exp(j*kd*(Y_r(:)*sin(phi_r(i,r))*sin(theta_r(i,r))+Z_r(:)*cos(theta_r(i,r))));%rx
                at = 1/sqrt(Nt)*exp(j*kd*(Y_t(:)*sin(phi_t_quantized(i,r))*sin(theta_t_quantized(i,r))+Z_t(:)*cos(theta_t_quantized(i,r))));%tx 
                ar = 1/sqrt(Nr)*exp(j*kd*(Y_r(:)*sin(phi_r_quantized(i,r))*sin(theta_r_quantized(i,r))+Z_r(:)*cos(theta_r_quantized(i,r))));%rx
                At = [At at]; % A matrix at tx
                Ar = [Ar ar]; % A matrix at rx
%                 alpha(:) = (randn(N_ray*N_cl,1) + j*randn(N_ray*N_cl,1))/sqrt(2); % gain
%                 alpha(:) = randn(1,N_ray) + j*randn(1,N_ray))/sqrt(2); % gain
                H = H + gamma * alpha(i,r) * ar * at'; % adding all rays
            end
        end
        
% %% 1. Optimal Unconstrained Precoding : SVD
%         [U, S, V] = svd(H); % SVD decomposition of H
%         V1 = V(1:Nt, 1:Ns);
%         
%         F_opt = V1; % tx; F_opt cannot be expressedd as F_RF*F_BB
%         W_opt = (1/sqrt(SNR) * inv(F_opt'*H'*H*F_opt + Ns/SNR*eye(Ns))*F_opt'*H')'; % rx, mmse
% 
% %         W_opt = ((1/sqrt(SNR))/(F_opt'*H'*H*F_opt + Ns/SNR*eye(Ns))*F_opt'*H')'
% %         W_opt = ((1/sqrt(SNR)) / (F_opt'*H'*H*F_opt + Ns/SNR*eye(Ns))*F_opt'*H')'; % rx, mmse
%         W_opt = W_opt/sqrt(trace(W_opt*W_opt'));
%         
%         W_opt_ZF = (1/sqrt(SNR) * inv(F_opt'*H'*H*F_opt)*F_opt'*H')'; % rx, mmse
%         W_opt_ZF = W_opt_ZF/sqrt(trace(W_opt_ZF*W_opt_ZF'));


%% Beam steering based on maximum ray gain

 % make it to row or column vector
        phi_t_col = phi_t(:); % make it as column vector
        theta_t_col = theta_t(:); % make it as column vector
        
%         phi_t_row = reshape(phi_t,1,[]);
%         theta_t_row = reshape(theta_t,1,[]);
%         
        phi_r_col = phi_r(:); % make column vector
        theta_r_col = theta_r(:); % make column vector
%         phi_r_row = reshape(phi_r,1,[]);
%         theta_r_row = reshape(theta_r,1,[]);

        [~,idx] = sort(abs(alpha(:)), 'descend'); % largest first
%         [~,idx] = max(abs(alpha(:)));
      
        F_beamsteer = [];
        W_beamsteer = [];
        for s=1:Ns % max Ns of alpha
            f_beamsteer = 1/sqrt(Nt)*exp(j*kd*(Y_t(:)*sin(phi_t_col(idx(s)))*sin(theta_t_col(idx(s)))+Z_t(:)*cos(theta_t_col(idx(s)))));
            F_beamsteer = [F_beamsteer f_beamsteer];
%             F_beamsteer = F_beamsteer/sqrt(trace(F_beamsteer*F_beamsteer'));
            w_beamsteer = 1/sqrt(Nr)*exp(j*kd*(Y_r(:)*sin(phi_r_col(idx(s)))*sin(theta_r_col(idx(s)))+Z_r(:)*cos(theta_r_col(idx(s)))));
            W_beamsteer = [W_beamsteer w_beamsteer];
            W_beamsteer = W_beamsteer/sqrt(trace(W_beamsteer*W_beamsteer'));


%             f_beamsteer = 1/sqrt(Nt)*exp(j*kd*(Y_t(:)*sin(phi_t_row(idx(s)))*sin(theta_t_row(idx(s)))+Z_t(:)*cos(theta_t_row(idx(s)))));
%             F_beamsteer = [F_beamsteer f_beamsteer];
%             w_beamsteer = 1/sqrt(Nr)*exp(j*kd*(Y_r(:)*sin(phi_r_row(idx(s)))*sin(theta_r_row(idx(s)))+Z_r(:)*cos(theta_r_row(idx(s)))));
%             W_beamsteer = [W_beamsteer w_beamsteer];

        end
        
%% 3. Spatially Sparse Precoding/Combining
        % Tx (Spatially Sparse Precoding, using OMP)
        F_RF = []; % empty matrix
        F_res = F_opt;
        for i = 1 : NRFt
            Psi = At' * F_res;
            [~,k] = max(diag(Psi * Psi'));
            F_RF = [F_RF At(:,k)];
%             F_BB = inv(F_RF'*F_RF)*F_RF'*F_opt;
            F_BB = (F_RF'*F_RF)\(F_RF'*F_opt);
            F_res = (F_opt-F_RF*F_BB)/norm(F_opt-F_RF*F_BB,'fro');
        end
        F_BB = sqrt(Ns) * F_BB/norm(F_RF*F_BB, 'fro');

        % Rx (Spatially sparse MMSE combining, using OMP)
        W_MMSE = (1/sqrt(SNR) * inv(F_BB'*F_RF'*H'*H*F_RF*F_BB + Ns/SNR*eye(Ns))*F_BB'*F_RF'*H')'; % rx, mmse
%         W_MMSE = ((sqrt(SNR)/Ns)*F_BB'*F_RF*H'*inv((SNR/Ns)*H*F_RF*F_BB*F_BB'*F_RF'*H'+eye(Nr)))';
%         W_MMSE = (1/sqrt(SNR) * inv(F_BB'*F_RF'*H'*H*F_RF*F_BB + Ns/SNR*eye(Ns))*F_BB'*F_RF'*H'); % rx, mmse
        W_RF = []; % empty matrix
        W_res = W_MMSE;
        Eyy = (SNR/Ns*H*F_RF*F_BB*F_BB'*F_RF'*H' + eye(Nr));
        for i=1:NRFr
            Psi = Ar'*Eyy*W_res;
            [~,k] = max(diag(Psi*Psi'));
            W_RF = [W_RF Ar(:,k)];
            W_BB = inv(W_RF'*Eyy*W_RF)*W_RF'*Eyy*W_MMSE;
            W_res = (W_MMSE - W_RF * W_BB)/norm(W_MMSE - W_RF * W_BB,'fro');
        end
        
                %%% Calculation of Spectral Efficiency

%         SE_hybrid_Ahm(SNR_index,n) = real(log2(det(eye(Ns)+SNR*(He*(f_bb*f_bb')*He'))));
                
%         Rn_opt = W_opt'*W_opt;
%         SE_optimal(Bits_index,n) = real(log2(det(eye(Ns)+SNR/Ns*inv(Rn_opt)*W_opt'*H*F_opt*F_opt'*H'*W_opt)));
%         SE_optimal(SNRLoop,n) = log2(real(det(eye(Ns)+SNR/Ns*inv(Rn)*W_opt'*H*F_opt*F_opt'*H'*W_opt)));

%         Rn_opt_ZF = W_opt_ZF'*W_opt_ZF;
%         SE_ZF(Num_Qbits,n) = real(log2(det(eye(Ns)+SNR/Ns*inv(Rn_opt_ZF)*W_opt_ZF'*H*F_opt*F_opt'*H'*W_opt_ZF)));

%         Rn_opt_ZF_2 = W_ZF'*W_ZF;
%         SE_ZF_2(SNR_index,n) = real(log2(det(eye(Ns)+SNR/Ns*inv(Rn_opt_ZF_2)*W_ZF'*H*F_ZF*F_ZF'*H'*W_ZF)));
%         Rn_Analog = w_rf'*w_rf;
%         SE_beamsteer(SNR_index,n) = real(log2(det(eye(Ns)+SNR/Ns*inv(Rn_Analog)*w_rf'*H*f_rf*f_rf'*H'*w_rf)));

        Rn = W_beamsteer'*W_beamsteer;
        SE_beamsteer(Bits_index,n) = real(log2(det(eye(Ns)+SNR/Ns*inv(Rn)*W_beamsteer'*H*F_beamsteer*F_beamsteer'*H'*W_beamsteer)));

        Rn_sparse = W_BB'*W_RF'*W_RF*W_BB;
        SE_hybrid(Bits_index,n) = real(log2(det(eye(Ns)+SNR/Ns*inv(Rn_sparse)*W_BB'*W_RF'*H*F_RF*F_BB*F_BB'*F_RF'*H'*W_RF*W_BB)));

    end
end

%% Plot
% plot(SNR_dB, mean(SE_optimal,2), 'r','LineWidth',2); hold on;
figure;
% plot(Num_Qbits, mean(SE_optimal,2), '-o','LineWidth',1.5); hold on;
plot(Num_Qbits, mean(SE_hybrid,2), '-^','LineWidth',1.5); hold on;
plot(Num_Qbits, mean(SE_beamsteer,2), '-*','LineWidth',1.5); hold on;

% plot(SNR_dB, mean(SE_ZF,2), 'g-'); hold on;
% plot(SNR_dB, mean(SE_Analog,2), 'y--o'); hold on;
% plot(SNR_dB, mean(SE_hybrid_Ahm,2), 'p--o'); hold on;
grid on;
xlabel('Num of Quantization bits');
ylabel('Spectral Efficiency (bits/s/Hz)');
legend('Sparse Precoding & Combining','Analog Beamforming');

        