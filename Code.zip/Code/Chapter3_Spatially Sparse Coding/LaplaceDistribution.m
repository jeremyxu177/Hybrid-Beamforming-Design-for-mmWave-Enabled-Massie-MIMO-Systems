function Y = LaplaceDistribution(mean, spread)

% Generation of Laplacian random variable
% Input
% mu: mean
% sv: standard deviation
% Output
% x: Laplacian random variable

b = spread/sqrt(2);

% Inverse transform
U = rand - 1/2;
Y = mean - b*sign(U)*log(1 - 2*abs(U));