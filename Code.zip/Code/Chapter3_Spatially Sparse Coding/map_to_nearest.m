function quantized_angle = map_to_nearest(original,codebook)
quantized_angle = [];

for i = 1:length(original)
    [~,index] = min(abs(original(i) - codebook))
    quantized_angle(i) = codebook(index);
%     quantized_angle = [quantized_angle quantized_angle(i)];
end