function H = generate_channel(Nt,Nr,N_cl,N_ray,azi_range,ele_range,As)
Ar = zeros(Nr,N_cl*N_ray);
At = zeros(Nr,N_cl*N_ray);
Nr_width = sqrt(Nr);
Nt_width = sqrt(Nt);
H = zeros(Nr,Nt);
gamma = sqrt(Nt*Nr/L)

for Nt_index = 1:length(Nt)
        %% channel realization
        phi_t_mean = phi_TX_min + (phi_TX_max - phi_TX_min)*rand(N_cl,1); % uniform random in [min, max]
        theta_t_mean = theta_TX_min + (theta_TX_max - theta_TX_min)*rand(N_cl,1);
        phi_r_mean = phi_RX_min + (phi_RX_max - phi_RX_min)*rand(N_cl,1);
        theta_r_mean = theta_RX_min + (theta_RX_max - theta_RX_min)*rand(N_cl,1);
        
        alpha = zeros(N_cl,N_ray);
        phi_t = zeros(N_cl,N_ray);
        theta_t = zeros(N_cl,N_ray); %8*10
        phi_r = zeros(N_cl,N_ray);
        theta_r = zeros(N_cl,N_ray);
        

        At = []; %steering vector
        Ar = [];
        H = zeros(Nr,Nt(Nt_index));   % Nr x Nt matrix H
        
        
        for i = 1:N_cl % for each cluster i
            phi_t(i,:) = laprnd(1,N_ray,phi_t_mean(i),As); % tx; iid laplacian distribution
            theta_t(i,:) = laprnd(1,N_ray,theta_t_mean(i),As);
            phi_r(i,:) = laprnd(1,N_ray,phi_r_mean(i),As); % rx
            theta_r(i,:) = laprnd(1,N_ray,theta_r_mean(i),As);
%             phi_t(i,:) = LaplaceDistribution(phi_t_mean(i),As); % tx; iid laplacian distribution
%             theta_t(i,:) = LaplaceDistribution(theta_t_mean(i),As);
%             phi_r(i,:) = LaplaceDistribution(phi_r_mean(i),As); % rx
%             theta_r(i,:) = LaplaceDistribution(theta_r_mean(i),As);
            alpha(i,:) = (randn(1,N_ray) + j*randn(1,N_ray))/sqrt(2); % gain

            for r = 1:N_ray % for each ray r
                % array response vector for UPA
                at = 1/sqrt(Nt(Nt_index))*exp(j*kd*(Y_t(:)*sin(phi_t(i,r))*sin(theta_t(i,r))+Z_t(:)*cos(theta_t(i,r))));%tx 
                ar = 1/sqrt(Nr)*exp(j*kd*(Y_r(:)*sin(phi_r(i,r))*sin(theta_r(i,r))+Z_r(:)*cos(theta_r(i,r))));%rx
                At = [At at]; % A matrix at tx
                Ar = [Ar ar]; % A matrix at rx
%                 alpha(:) = (randn(N_ray*N_cl,1) + j*randn(N_ray*N_cl,1))/sqrt(2); % gain
%                 alpha(:) = randn(1,N_ray) + j*randn(1,N_ray))/sqrt(2); % gain
                H = H + gamma(Nt_index) * alpha(i,r) * ar * at'; % adding all rays
            end
        end

end