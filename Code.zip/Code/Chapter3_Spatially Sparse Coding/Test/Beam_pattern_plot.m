load('data.mat');


ha = F_opt;
ha.Element.BackBaffled = true;
plotresponse(ha,3e8,As,'RespCut','3D','Format','Polar');